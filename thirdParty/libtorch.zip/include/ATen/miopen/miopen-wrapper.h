#pragma once

#include <miopen/miopen.h>
